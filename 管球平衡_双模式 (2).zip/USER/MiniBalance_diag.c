/***********************************************
 * F32C 电机ID诊断程序
 *
 * 目的: 找出每个电机实际响应的ID
 *
 * 现象判断:
 *   - 如果只有电机A动 → 两个电机ID相同,都响应了同一个ID
 *   - 如果电机A和B交替动 → ID分配正确,ID1和ID2对应不同电机
 *   - 如果都不动 → 串口通信或供电有问题
 ***********************************************/

#include "stm32f10x.h"
#include "sys.h"

int Encoder_cnt, Encoder_pr;
int Motor1_Speed = 200, Motor2_Speed = 200;
int motor1_Current_Speed, motor2_Current_Speed;
int Motor1_T_Position = 0, Motor2_T_Position = 0;
int Motor1_Current_Position, Motor2_Current_Position;

extern u8 usart2_receive_data[10];

u8 motor1_ID = 1, motor2_ID = 2;
u8 motor1_Mode = 1, motor2_Mode = 1;

u8 motor1_Enable_data[5]  = {0x7A, 0x01, 0x06, 0x7D, 0x7B};
u8 motor2_Enable_data[5]  = {0x7A, 0x02, 0x06, 0x7E, 0x7B};
u8 motor1_Mode_data[7]    = {0x7A, 0x01, 0x00, 0x00, 0x00, 0x7B, 0x7B};
u8 motor2_Mode_data[7]    = {0x7A, 0x02, 0x00, 0x00, 0x00, 0x78, 0x7B};
u8 motor1_Speed_data_task[7] = {0x7A, 0x01, 0x01, 0x00, 0x00, 0x00, 0x7B};
u8 motor2_Speed_data_task[7] = {0x7A, 0x02, 0x01, 0x00, 0x00, 0x00, 0x7B};
u8 motor1_Position_data_task[9] = {0x7A, 0x01, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7B};
u8 motor2_Position_data_task[9] = {0x7A, 0x02, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7B};
u8 motor1_Feedback_data[6] = {0x7A, 0x01, 0x0E, 0x01, 0x74, 0x7B};
u8 motor2_Feedback_data[6] = {0x7A, 0x02, 0x0E, 0x01, 0x77, 0x7B};

void Send_Position(u8 motor_id, u8 *frame, int target_position)
{
    frame[1] = motor_id;
    frame[3] = (target_position >> 24) & 0xFF;
    frame[4] = (target_position >> 16) & 0xFF;
    frame[5] = (target_position >> 8)  & 0xFF;
    frame[6] =  target_position        & 0xFF;
    frame[7] = BCC_Sum1(frame, 7);
    USART2_SEND(frame, 9);
}

int main(void)
{
    MY_NVIC_PriorityGroupConfig(2);
    delay_init();
    JTAG_Set(JTAG_SWD_DISABLE);
    JTAG_Set(SWD_ENABLE);
    uart_init(115200);
    uart2_init(115200);
    OLED_Init();
    KEY_Init();

    printf("\r\n========== ID Diagnostic ==========\r\n");

    usart2_send(0x00);
    delay_ms(1500);
    printf("[OK] Driver ready\r\n");

    /* 使能两个电机 */
    motor1_Enable_data[1] = motor1_ID;
    motor1_Enable_data[3] = BCC_Sum1(motor1_Enable_data, 3);
    USART2_SEND(motor1_Enable_data, sizeof(motor1_Enable_data));
    delay_ms(10);

    motor2_Enable_data[1] = motor2_ID;
    motor2_Enable_data[3] = BCC_Sum1(motor2_Enable_data, 3);
    USART2_SEND(motor2_Enable_data, sizeof(motor2_Enable_data));
    delay_ms(10);
    printf("[OK] Both motors enabled\r\n");

    /* 都设位置模式 */
    motor1_Mode_data[1] = motor1_ID;
    motor1_Mode_data[3] = motor1_Mode >> 8;
    motor1_Mode_data[4] = motor1_Mode;
    motor1_Mode_data[5] = BCC_Sum1(motor1_Mode_data, 5);
    USART2_SEND(motor1_Mode_data, sizeof(motor1_Mode_data));
    delay_ms(10);

    motor2_Mode_data[1] = motor2_ID;
    motor2_Mode_data[3] = motor2_Mode >> 8;
    motor2_Mode_data[4] = motor2_Mode;
    motor2_Mode_data[5] = BCC_Sum1(motor2_Mode_data, 5);
    USART2_SEND(motor2_Mode_data, sizeof(motor2_Mode_data));
    delay_ms(10);
    printf("[OK] Both in position mode\r\n");

    /* 设最大速度 */
    motor1_Speed_data_task[1] = motor1_ID;
    motor1_Speed_data_task[3] = Motor1_Speed >> 8;
    motor1_Speed_data_task[4] = Motor1_Speed;
    motor1_Speed_data_task[5] = BCC_Sum1(motor1_Speed_data_task, 5);
    USART2_SEND(motor1_Speed_data_task, sizeof(motor1_Speed_data_task));
    delay_ms(10);

    motor2_Speed_data_task[1] = motor2_ID;
    motor2_Speed_data_task[3] = Motor2_Speed >> 8;
    motor2_Speed_data_task[4] = Motor2_Speed;
    motor2_Speed_data_task[5] = BCC_Sum1(motor2_Speed_data_task, 5);
    USART2_SEND(motor2_Speed_data_task, sizeof(motor2_Speed_data_task));
    delay_ms(10);

    printf("\r\n--- Phase 1: Only ID1, sweep 0<->+45 deg ---\r\n");
    printf(">>> Which motor moves? X(bottom) or Y(top)? <<<\r\n");

    /* ---- 阶段1: 只让ID1来回扫，看哪个电机动 ---- */
    int phase1_counter = 0;
    int phase1_target = 0;
    while (1)
    {
        phase1_counter++;
        if (phase1_counter > 200)
        {
            phase1_counter = 0;
            phase1_target = (phase1_target == 0) ? 450 : 0; // 0° ↔ 45°
            printf("  ID1 target -> %.1f deg\r\n", phase1_target / 10.0);
        }

        /* 只发ID1扫，ID2锁0 */
        Send_Position(1, motor1_Position_data_task, phase1_target);
        delay_ms(5);
        Send_Position(2, motor2_Position_data_task, 0);
        delay_ms(5);
        delay_ms(10);
    }
}
