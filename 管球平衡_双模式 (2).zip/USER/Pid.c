#include "Pid.h"
#include "stdio.h"

void PID_Init(PidTypeDef *pid, uint8_t mode, const float PID[3], float max_out, float max_iout)
{
    int i;
    if(pid == NULL || PID == NULL) return;

    pid->mode = mode;
    pid->Kp = PID[0];
    pid->Ki = PID[1];
    pid->Kd = PID[2];
    pid->max_out = max_out;
    pid->max_iout = max_iout;

    // 初始化历史数据
    for(i = 0; i < 3; i++)
    {
        pid->Dbuf[i] = 0.0f;
        pid->error[i] = 0.0f;
    }

    pid->Pout = 0.0f;
    pid->Iout = 0.0f;
    pid->Dout = 0.0f;
    pid->out = 0.0f;
    pid->fdb = 0.0f;
    pid->set = 0.0f;
}

float PID_Calc(PidTypeDef *pid, float ref, float set)
{
    if(pid == NULL) return 0.0f;

    // ǰ����ʷ����
    pid->error[2] = pid->error[1];
    pid->error[1] = pid->error[0];
    pid->Dbuf[2] = pid->Dbuf[1];
    pid->Dbuf[1] = pid->Dbuf[0];

    // ���µ�ǰ����
    pid->set = set;
    pid->fdb = ref;
    pid->error[0] = set - ref;

    // λ��ʽPID
    if(pid->mode == PID_POSITION)
    {
        pid->Pout = pid->Kp * pid->error[0];

        // ���������
        pid->Iout += pid->Ki * pid->error[0];
        LimitMax(pid->Iout, pid->max_iout);

        // ΢�������
        pid->Dbuf[0] = pid->error[0] - pid->error[1];
        pid->Dout = pid->Kd * pid->Dbuf[0];

        // �����
        pid->out = pid->Pout + pid->Iout + pid->Dout;
        LimitMax(pid->out, pid->max_out);
    }
    // ����ʽPID
    else if(pid->mode == PID_DELTA)
    {
        pid->Pout = pid->Kp * (pid->error[0] - pid->error[1]);
        pid->Iout = pid->Ki * pid->error[0];

        // ����΢��
        pid->Dbuf[0] = pid->error[0] - 2 * pid->error[1] + pid->error[2];
        pid->Dout = pid->Kd * pid->Dbuf[0];

        // �������
        pid->out += pid->Pout + pid->Iout + pid->Dout;
        LimitMax(pid->out, pid->max_out);
    }

    return pid->out;
}

void PID_clear(PidTypeDef *pid)
{
    int i;
    if(pid == NULL) return;

    for(i = 0; i < 3; i++)
    {
        pid->Dbuf[i] = 0.0f;
        pid->error[i] = 0.0f;
    }

    pid->Pout = 0.0f;
    pid->Iout = 0.0f;
    pid->Dout = 0.0f;
    pid->out = 0.0f;
    pid->fdb = 0.0f;
    pid->set = 0.0f;
}

void pid_reset(PidTypeDef *pid, float p, float i, float d)
{
    if(pid == NULL) return;

    pid->Kp = p;
    pid->Ki = i;
    pid->Kd = d;

    // �����޷�������ֻ���ü������
    pid->Pout = 0.0f;
    pid->Iout = 0.0f;
    pid->Dout = 0.0f;
    pid->out = 0.0f;
}

#define PWM_MAX 9999

