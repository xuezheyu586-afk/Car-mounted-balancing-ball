/***********************************************
 * F32C 云台双电机测试代码
 *
 * 功能:
 *   X轴电机(ID1): 位置闭环锁定在0°,不动
 *   Y轴电机(ID2): 位置闭环来回扫描 ±30°
 *
 * 接线:
 *   STM32F103C8T6  →  云台GH1.25-5PIN总接口
 *   GND             →  GND
 *   PA2 (USART2_TX) →  RXD (电机收)
 *   PA3 (USART2_RX) →  TXD (电机发)
 *   12V外接电源      →  VCC (电机供电)
 *   ⚠ 12V电源GND必须和STM32的GND共地!
 *
 * 串口1 (PA9/PA10): 调试输出,115200波特率
 * 串口2 (PA2/PA3):  电机通信,115200波特率
 *
 * 使用方法:
 *   用本文件替换原 MiniBalance.c,再编译下载
 ***********************************************/

#include "stm32f10x.h"
#include "sys.h"

/* ========== 全局变量 ========== */
int Encoder_cnt, Encoder_pr;
int Motor1_Speed = 50,  Motor2_Speed = 200;     // X轴慢速,Y轴快速(位置模式下的最大速度)
int motor1_Current_Speed, motor2_Current_Speed;
int Motor1_T_Position = 0, Motor2_T_Position = 0; // 目标角度 (单位: 0.1°)
int Motor1_Current_Position, Motor2_Current_Position; // 当前实际角度

extern u8 usart2_receive_data[10];

/* ========== 电机配置 ========== */
u8 motor1_ID = 1, motor2_ID = 2;

/* 模式: 0=速度模式, 1=多圈位置+T曲线, 2=多圈位置无T曲线 */
u8 motor1_Mode = 1, motor2_Mode = 1;

/* ---- 协议帧模板 ---- */
u8 motor1_Enable_data[5]  = {0x7A, 0x01, 0x06, 0x7D, 0x7B};
u8 motor2_Enable_data[5]  = {0x7A, 0x02, 0x06, 0x7E, 0x7B};

u8 motor1_Mode_data[7]    = {0x7A, 0x01, 0x00, 0x00, 0x00, 0x7B, 0x7B};
u8 motor2_Mode_data[7]    = {0x7A, 0x02, 0x00, 0x00, 0x00, 0x78, 0x7B};

u8 motor1_Speed_data_task[7] = {0x7A, 0x01, 0x01, 0x00, 0x00, 0x00, 0x7B};
u8 motor2_Speed_data_task[7] = {0x7A, 0x02, 0x01, 0x00, 0x00, 0x00, 0x7B};

u8 motor1_Position_data_task[9] = {0x7A, 0x01, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7B};
u8 motor2_Position_data_task[9] = {0x7A, 0x02, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7B};

u8 motor1_Feedback_data[6] = {0x7A, 0x01, 0x0E, 0x01, 0x74, 0x7B};
u8 motor2_Feedback_data[6] = {0x7A, 0x02, 0x0E, 0x01, 0x77, 0x7B};


/* ========== 辅助函数: 发送位置指令 ========== */
void Send_Position(u8 motor_id, u8 *frame, int target_position)
{
    frame[1] = motor_id;
    frame[3] = (target_position >> 24) & 0xFF;
    frame[4] = (target_position >> 16) & 0xFF;
    frame[5] = (target_position >> 8)  & 0xFF;
    frame[6] =  target_position        & 0xFF;
    frame[7] = BCC_Sum1(frame, 7);
    USART2_SEND(frame, 9);
}


/* ========== 主函数 ========== */
int main(void)
{
    /* ---- 系统初始化 ---- */
    MY_NVIC_PriorityGroupConfig(2);
    delay_init();
    JTAG_Set(JTAG_SWD_DISABLE);
    JTAG_Set(SWD_ENABLE);

    uart_init(115200);       // USART1: 调试串口
    uart2_init(115200);      // USART2: 电机通信
    OLED_Init();
    KEY_Init();

    printf("\r\n");
    printf("========================================\r\n");
    printf("  F32C Gimbal Dual-Motor Test\r\n");
    printf("  X(ID1): locked at 0 deg\r\n");
    printf("  Y(ID2): sweep +/-30 deg\r\n");
    printf("========================================\r\n\r\n");

    /* ---- 唤醒串口 ---- */
    usart2_send(0x00);
    delay_ms(1500);          // 等驱动器上电就绪
    printf("[OK] Driver ready after 1.5s\r\n");

    /* ---- 1. 使能电机1 (X轴) ---- */
    motor1_Enable_data[1] = motor1_ID;
    motor1_Enable_data[3] = BCC_Sum1(motor1_Enable_data, 3);
    USART2_SEND(motor1_Enable_data, sizeof(motor1_Enable_data));
    printf("[OK] Motor1 (X) enabled\r\n");
    delay_ms(10);

    /* ---- 1. 使能电机2 (Y轴) ---- */
    motor2_Enable_data[1] = motor2_ID;
    motor2_Enable_data[3] = BCC_Sum1(motor2_Enable_data, 3);
    USART2_SEND(motor2_Enable_data, sizeof(motor2_Enable_data));
    printf("[OK] Motor2 (Y) enabled\r\n");
    delay_ms(10);

    /* ---- 2. 设电机1为位置模式 ---- */
    motor1_Mode_data[1] = motor1_ID;
    motor1_Mode_data[3] = motor1_Mode >> 8;
    motor1_Mode_data[4] = motor1_Mode;
    motor1_Mode_data[5] = BCC_Sum1(motor1_Mode_data, 5);
    USART2_SEND(motor1_Mode_data, sizeof(motor1_Mode_data));
    printf("[OK] Motor1 (X) -> Position Mode\r\n");
    delay_ms(10);

    /* ---- 2. 设电机2为位置模式 ---- */
    motor2_Mode_data[1] = motor2_ID;
    motor2_Mode_data[3] = motor2_Mode >> 8;
    motor2_Mode_data[4] = motor2_Mode;
    motor2_Mode_data[5] = BCC_Sum1(motor2_Mode_data, 5);
    USART2_SEND(motor2_Mode_data, sizeof(motor2_Mode_data));
    printf("[OK] Motor2 (Y) -> Position Mode\r\n");
    delay_ms(10);

    /* ---- 3. 设置最大速度 ---- */
    motor1_Speed_data_task[1] = motor1_ID;
    motor1_Speed_data_task[3] = Motor1_Speed >> 8;
    motor1_Speed_data_task[4] = Motor1_Speed;
    motor1_Speed_data_task[5] = BCC_Sum1(motor1_Speed_data_task, 5);
    USART2_SEND(motor1_Speed_data_task, sizeof(motor1_Speed_data_task));
    delay_ms(10);

    motor2_Speed_data_task[1] = motor2_ID;
    motor2_Speed_data_task[3] = Motor2_Speed >> 8;
    motor2_Speed_data_task[4] = Motor2_Speed;
    motor2_Speed_data_task[5] = BCC_Sum1(motor2_Speed_data_task, 5);
    USART2_SEND(motor2_Speed_data_task, sizeof(motor2_Speed_data_task));
    printf("[OK] Speed limits: X=%d, Y=%d\r\n", Motor1_Speed, Motor2_Speed);
    delay_ms(10);

    /* ---- 初始化定时器（按键检测用） ---- */
    TIM1_Init(7199, 99);

    printf("\r\n>>> Test running! Press KEY to add 90deg <<<\r\n");
    printf(">>> Open serial monitor at 115200 to see real-time data <<<\r\n\r\n");

    /* ---- 扫描状态机 ---- */
    int sweep_step = 0;
    // 扫描序列: 0° → +30° → 0° → -30° → 0° (循环)
    int sweep_targets[5] = {0, 300, 0, -300, 0};
    int sweep_counter = 0;
    #define SWEEP_HOLD_MS  1500   // 每个目标停1.5秒

    int print_counter = 0;

    while (1)
    {
        /* ---- 扫描逻辑 ---- */
        sweep_counter++;
        if (sweep_counter >= SWEEP_HOLD_MS)
        {
            sweep_counter = 0;
            sweep_step = (sweep_step + 1) % 5;
            Motor2_T_Position = sweep_targets[sweep_step];
            printf("[SWEEP] Y-axis target -> %.1f deg\r\n",
                   Motor2_T_Position / 10.0);
        }

        /* X轴始终锁定在0° */
        Motor1_T_Position = 0;

        /* ---- 发送位置指令 ---- */
        Send_Position(motor1_ID, motor1_Position_data_task, Motor1_T_Position);
        delay_ms(5);

        Send_Position(motor2_ID, motor2_Position_data_task, Motor2_T_Position);
        delay_ms(5);

        /* ---- 查询实时位置 ---- */
        motor1_Feedback_data[1] = motor1_ID;
        motor1_Feedback_data[4] = BCC_Sum1(motor1_Feedback_data, 4);
        USART2_SEND(motor1_Feedback_data, sizeof(motor1_Feedback_data));
        delay_ms(5);

        motor2_Feedback_data[1] = motor2_ID;
        motor2_Feedback_data[4] = BCC_Sum1(motor2_Feedback_data, 4);
        USART2_SEND(motor2_Feedback_data, sizeof(motor2_Feedback_data));
        delay_ms(5);

        /* ---- 周期性打印当前位置 ---- */
        print_counter++;
        if (print_counter >= 50)  // 约每250ms打印一次
        {
            print_counter = 0;
            printf("POS> X:%.1f deg (target:%.1f) | Y:%.1f deg (target:%.1f)\r\n",
                   Motor1_Current_Position / 10.0,
                   Motor1_T_Position / 10.0,
                   Motor2_Current_Position / 10.0,
                   Motor2_T_Position / 10.0);
        }

        /* OLED 显示（同原例程） */
        OLED_Show();
    }
}
