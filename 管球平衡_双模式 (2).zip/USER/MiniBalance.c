/***********************************************
 * F32C 云台 — 双模式 (PC13按键循环切换)
 *
 * 模式一: 写死位置序列 (完全复刻F32C参考项目, delay控制时间)
 * 模式二: 摄像头物理偏移PID闭环
 *
 * 接线:
 *   STM32F103  →  云台GH1.25-5PIN总接口
 *   GND        →  GND
 *   PA2 (TX)   →  RXD (电机收)
 *   PA3 (RX)   →  TXD (电机发)
 *   PC13       →  按键(低电平有效, 每次按下切换模式)
 *   12V外接    →  VCC (电机供电)
 ***********************************************/

#include "stm32f10x.h"
#include "sys.h"
#include "Pid.h"

/* ========== 模式定义 ========== */
#define MODE_1  1
#define MODE_2  2

/* ========== 模式一: 位置序列 (只改这三个数组) ========== */
#define M1_SEQ_LEN           7
#define M1_ARRIVE_TOLERANCE  20   /* 到位容差 ±2.0° */

int m1_seq_target[M1_SEQ_LEN] = {570, 280, 600, 800, 670 ,650};
int m1_seq_hold[M1_SEQ_LEN]   = { 500, 1400,1000, 930,  0, -1};  /* ms, -1=永远停 */
int m1_seq_speed[M1_SEQ_LEN]  = { 50, 120,  70,  90,  50, 30,50};

/* ========== 模式二: 相机PID ========== */
#define M2_MOTOR_BASE     500
#define M2_PID_MAX_OUT    20.0f
#define M2_PID_MAX_IOUT   4.0f
#define M2_MOTOR_MAX_DEV  300
#define M2_DEAD_ZONE      5
#define M2_MOTOR_SPEED    230
#define CAMERA_CENTER     0

float g_pid_kp = 0.05f;
float g_pid_ki = 0.01f;
float g_pid_kd = 3.0f;

/* ========== 摄像头数据 ========== */
volatile int camera_error_x  = 0;
volatile int camera_error_y  = 0;
volatile int camera_w        = 0;
volatile int camera_h        = 0;
volatile u8  camera_ball_flag   = 1;
volatile u8  camera_data_ready  = 0;

/* ========== 全局 ========== */
int Motor2_Speed = 50;
int Motor1_T_Position = 0;
int Motor1_Current_Position = 0;
int Motor2_T_Position = 0;
int Motor2_Current_Position;
u8   pid_in_deadzone = 1;
u8   current_mode = MODE_1;
float pid_out = 0.0f;

extern u8 usart2_receive_data[10];
extern volatile u8   vofa_cmd_ready;
extern volatile u8   vofa_param_id;
extern volatile float vofa_param_value;

/* ========== 电机协议帧 ========== */
u8 motor2_ID = 2;
u8 motor2_Mode = 1;
u8 motor2_Enable_data[5]        = {0x7A, 0x02, 0x06, 0x7E, 0x7B};
u8 motor2_Mode_data[7]          = {0x7A, 0x02, 0x00, 0x00, 0x00, 0x78, 0x7B};
u8 motor2_Speed_data_task[7]    = {0x7A, 0x02, 0x01, 0x00, 0x00, 0x00, 0x7B};
u8 motor2_Position_data_task[9] = {0x7A, 0x02, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x7B};
u8 motor2_Feedback_data[6]      = {0x7A, 0x02, 0x0E, 0x01, 0x77, 0x7B};

/* ========== 按键 (PC13) ========== */
extern volatile u32 sys_tick_ms;
u32 GetTick(void) { return sys_tick_ms; }
static int my_abs(int x) { return (x >= 0) ? x : -x; }

void Button_Init(void)
{
    GPIO_InitTypeDef s;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    s.GPIO_Pin  = GPIO_Pin_13;
    s.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOC, &s);
}
u8 Button_Read(void)
{
    return (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) == Bit_RESET) ? 1 : 0;
}
u8 Button_Scan(void)
{
    static u8 last = 0;
    static u32 last_t = 0;
    u8 cur = Button_Read();
    u8 r = 0;
    if (last == 0 && cur == 1) {
        u32 now = GetTick();
        if ((now - last_t) > 200) { r = 1; last_t = now; }
    }
    last = cur;
    return r;
}

/* ========== 电机通信辅助 ========== */
void Send_Position(u8 id, u8 *frame, int pos)
{
    frame[1] = id;
    frame[3] = (pos >> 24) & 0xFF;
    frame[4] = (pos >> 16) & 0xFF;
    frame[5] = (pos >> 8)  & 0xFF;
    frame[6] =  pos        & 0xFF;
    frame[7] = BCC_Sum1(frame, 7);
    USART2_SEND(frame, 9);
}
void Send_Speed(int speed)
{
    Motor2_Speed = speed;
    motor2_Speed_data_task[1] = motor2_ID;
    motor2_Speed_data_task[3] = Motor2_Speed >> 8;
    motor2_Speed_data_task[4] = Motor2_Speed;
    motor2_Speed_data_task[5] = BCC_Sum1(motor2_Speed_data_task, 5);
    USART2_SEND(motor2_Speed_data_task, sizeof(motor2_Speed_data_task));
}
void Query_Feedback(void)
{
    motor2_Feedback_data[1] = motor2_ID;
    motor2_Feedback_data[4] = BCC_Sum1(motor2_Feedback_data, 4);
    USART2_SEND(motor2_Feedback_data, sizeof(motor2_Feedback_data));
}
void Motor_Init(int base, int speed)
{
    usart2_send(0x00);
    delay_ms(1500);
    motor2_Enable_data[1] = motor2_ID;
    motor2_Enable_data[3] = BCC_Sum1(motor2_Enable_data, 3);
    USART2_SEND(motor2_Enable_data, sizeof(motor2_Enable_data));
    delay_ms(10);
    motor2_Mode_data[1] = motor2_ID;
    motor2_Mode_data[3] = motor2_Mode >> 8;
    motor2_Mode_data[4] = motor2_Mode;
    motor2_Mode_data[5] = BCC_Sum1(motor2_Mode_data, 5);
    USART2_SEND(motor2_Mode_data, sizeof(motor2_Mode_data));
    delay_ms(50);
    Send_Speed(speed);
    delay_ms(10);
    Motor2_T_Position = base;
    Send_Position(motor2_ID, motor2_Position_data_task, Motor2_T_Position);
    delay_ms(5);
}

/* ========== VOFA+ 命令 ========== */
void VOFA_ProcessCommand(void)
{
    if (vofa_cmd_ready == 0) return;
    vofa_cmd_ready = 0;
    switch (vofa_param_id)
    {
    case 1: g_pid_kp = vofa_param_value; printf("[VOFA] Kp=%.3f\r\n", g_pid_kp); break;
    case 2: g_pid_ki = vofa_param_value; printf("[VOFA] Ki=%.3f\r\n", g_pid_ki); break;
    case 3: g_pid_kd = vofa_param_value; printf("[VOFA] Kd=%.3f\r\n", g_pid_kd); break;
    }
}

/* ========== 模式切换 ========== */
void Switch_Mode(PidTypeDef *pid, u8 new_mode)
{
    current_mode = new_mode;
    PID_clear(pid);
    pid_in_deadzone = 1;
    pid_out = 0.0f;

    if (new_mode == MODE_1)
    {
        printf("[MODE] Mode 1: sequence\r\n");
    }
    else
    {
        float p[3];
        p[0] = g_pid_kp; p[1] = g_pid_ki; p[2] = g_pid_kd;
        PID_Init(pid, PID_POSITION, p, M2_PID_MAX_OUT, M2_PID_MAX_IOUT);
        Send_Speed(M2_MOTOR_SPEED);
        Motor2_T_Position = M2_MOTOR_BASE;
        printf("[MODE] Mode 2: PID, base=%d\r\n", M2_MOTOR_BASE);
    }
}

/* ================================================================
 * 模式一: 位置序列 (完全复刻F32C参考项目)
 *
 * 关键: 位置指令只在步进切换时发一次!
 *       运动中只查反馈, 保持时用delay分块+心跳
 * ================================================================ */
void Mode1_Loop(void)
{
    int step;
    int cur_speed = 0;

    /* ---- 初始化: 发第一步 ---- */
    step = 0;
    Send_Speed(m1_seq_speed[0]);
    cur_speed = m1_seq_speed[0];
    delay_ms(10);
    Motor2_T_Position = m1_seq_target[0];
    Send_Position(motor2_ID, motor2_Position_data_task, m1_seq_target[0]);
    delay_ms(5);

    while (current_mode == MODE_1)
    {
        int target = m1_seq_target[step];
        int hold   = m1_seq_hold[step];
        int arrived = 0;

        /* ============================================
         * 运动中: 只查反馈 + 等到位
         * 不重发位置! 不发心跳! 让T曲线跑完
         * ============================================ */
        while (!arrived && current_mode == MODE_1)
        {
            Query_Feedback();
            delay_ms(4);

            if (my_abs(Motor2_Current_Position - target) <= M1_ARRIVE_TOLERANCE)
                arrived = 1;

            /* 运动中也检查按键 (不阻塞) */
            if (Button_Scan())
            {
                Switch_Mode(NULL, MODE_2);
                return;
            }
        }
        if (current_mode != MODE_1) return;

        /* ============================================
         * 到位 → 保持 (用delay分块, 每50ms发心跳)
         * ============================================ */
        if (hold == -1)
        {
            /* 永远停在这里 */
            while (current_mode == MODE_1)
            {
                Send_Position(motor2_ID, motor2_Position_data_task, target);
                delay_ms(2);
                Query_Feedback();
                delay_ms(48);   /* 50ms一次心跳 */

                if (Button_Scan())
                {
                    Switch_Mode(NULL, MODE_2);
                    return;
                }
            }
            return;
        }
        else if (hold > 0)
        {
            int remaining = hold;
            while (remaining > 0 && current_mode == MODE_1)
            {
                int chunk = (remaining > 50) ? 50 : remaining;
                delay_ms(chunk);
                remaining -= chunk;

                /* 心跳: 重发位置防超时 */
                Send_Position(motor2_ID, motor2_Position_data_task, target);
                delay_ms(2);
                Query_Feedback();
                delay_ms(2);

                /* 保持期间可按键切换 */
                if (Button_Scan())
                {
                    Switch_Mode(NULL, MODE_2);
                    return;
                }
            }
        }
        /* hold==0 则不保持, 立刻切下一步 */
        if (current_mode != MODE_1) return;

        /* ---- 切下一步 ---- */
        step++;
        if (step >= M1_SEQ_LEN) step = M1_SEQ_LEN - 1;

        /* 速度变了才发 */
        if (m1_seq_speed[step] != cur_speed)
        {
            Send_Speed(m1_seq_speed[step]);
            cur_speed = m1_seq_speed[step];
            delay_ms(10);
        }

        /* 发新目标位置 (只发一次!) */
        Motor2_T_Position = m1_seq_target[step];
        Send_Position(motor2_ID, motor2_Position_data_task, m1_seq_target[step]);
        delay_ms(5);

        printf("[M1] step=%d target=%d speed=%d\r\n", step,
               m1_seq_target[step], m1_seq_speed[step]);
    }
}

/* ================================================================
 * 模式二: 相机PID (无改动)
 * ================================================================ */
void Mode2_Run(PidTypeDef *pid)
{
    if (!camera_data_ready) return;
    camera_data_ready = 0;

    if (camera_ball_flag == 0x01)
    {
        float raw_err = (float)(camera_error_x - CAMERA_CENTER);
        float abs_err = (raw_err > 0.0f) ? raw_err : -raw_err;

        pid->Kp = g_pid_kp;
        pid->Ki = g_pid_ki;
        pid->Kd = g_pid_kd;

        if (abs_err > M2_DEAD_ZONE)
        {
            if (pid_in_deadzone) { PID_clear(pid); pid_in_deadzone = 0; }
            pid_out = PID_Calc(pid, 0.0f, raw_err) * 1.0f;
            Motor2_T_Position = M2_MOTOR_BASE + (int)(pid_out * 10.0f);
            if (Motor2_T_Position > M2_MOTOR_BASE + M2_MOTOR_MAX_DEV)
                Motor2_T_Position = M2_MOTOR_BASE + M2_MOTOR_MAX_DEV;
            if (Motor2_T_Position < M2_MOTOR_BASE - M2_MOTOR_MAX_DEV)
                Motor2_T_Position = M2_MOTOR_BASE - M2_MOTOR_MAX_DEV;
            printf("[M2] err=%d pid=%.2f motor=%d\r\n",
                   camera_error_x, pid_out, Motor2_T_Position);
        }
        else
        {
            if (!pid_in_deadzone) { PID_clear(pid); pid_in_deadzone = 1; }
            Motor2_T_Position = M2_MOTOR_BASE;
        }
    }
    else
    {
        Motor2_T_Position = M2_MOTOR_BASE;
        PID_clear(pid);
        pid_in_deadzone = 1;
    }
}

/* ========== 主函数 ========== */
int main(void)
{
    PidTypeDef pid_y;
    float vofa_data[5];
    float p[3];

    /* ---- 系统初始化 ---- */
    MY_NVIC_PriorityGroupConfig(2);
    delay_init();
    SysTick_Config(SystemCoreClock / 1000);
    JTAG_Set(JTAG_SWD_DISABLE);
    JTAG_Set(SWD_ENABLE);
    uart_init(115200);
    uart2_init(115200);
    uart3_init(115200);
    Button_Init();

    /* ---- 初始化PID (模式二用) ---- */
    p[0] = g_pid_kp; p[1] = g_pid_ki; p[2] = g_pid_kd;
    PID_Init(&pid_y, PID_POSITION, p, M2_PID_MAX_OUT, M2_PID_MAX_IOUT);

    /* ---- 电机上电 ---- */
    usart2_send(0x00);
    delay_ms(1500);
    motor2_Enable_data[1] = motor2_ID;
    motor2_Enable_data[3] = BCC_Sum1(motor2_Enable_data, 3);
    USART2_SEND(motor2_Enable_data, sizeof(motor2_Enable_data));
    delay_ms(10);
    motor2_Mode_data[1] = motor2_ID;
    motor2_Mode_data[3] = motor2_Mode >> 8;
    motor2_Mode_data[4] = motor2_Mode;
    motor2_Mode_data[5] = BCC_Sum1(motor2_Mode_data, 5);
    USART2_SEND(motor2_Mode_data, sizeof(motor2_Mode_data));
    delay_ms(50);

    /* ---- 默认模式一 ---- */
    current_mode = MODE_1;
    printf("[MODE] Mode 1: position sequence\r\n");

    /* ---- 主循环 ---- */
    while (1)
    {
        /* VOFA+ 命令 */
        VOFA_ProcessCommand();

        /* 按键 → 切换模式 */
        if (Button_Scan())
        {
            u8 next = (current_mode == MODE_1) ? MODE_2 : MODE_1;
            Switch_Mode(&pid_y, next);
        }

        /* =====================================
         * 模式一: 位置序列 (内部用delay控制时间)
         * ===================================== */
        if (current_mode == MODE_1)
        {
            Mode1_Loop();
        }

        /* =====================================
         * 模式二: 相机PID
         * ===================================== */
        if (current_mode == MODE_2)
        {
            /* 消费可能残留的摄像头帧 */
            if (camera_data_ready)
            {
                Mode2_Run(&pid_y);
            }

            /* VOFA+ FireWater 数据 (每~50ms) */
            {
                static u32 vofa_tick = 0;
                if (++vofa_tick >= 10)
                {
                    vofa_tick = 0;
                    vofa_data[0] = camera_error_x / 100.0f;
                    vofa_data[1] = CAMERA_CENTER  / 100.0f;
                    vofa_data[2] = pid_out;
                    vofa_data[3] = Motor2_T_Position / 10.0f;
                    vofa_data[4] = (float)camera_ball_flag;
                    VOFA_SendFireWater(vofa_data, 5);
                }
            }

            /* 发送位置指令 */
            Send_Position(motor2_ID, motor2_Position_data_task, Motor2_T_Position);
            delay_ms(2);

            /* 查询实时位置 */
            Query_Feedback();
            delay_ms(2);
        }
    }
}
