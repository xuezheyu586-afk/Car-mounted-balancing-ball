/***********************************************
公司：轮趣科技(东莞)有限公司
品牌：WHEELTEC
官网：wheeltec.net
淘宝店铺：shop114407458.taobao.com
速卖通: https://minibalance.aliexpress.com/store/4455017
版本：V1.0
修改时间：2022-09-01

Brand: WHEELTEC
Website: wheeltec.net
Taobao shop: shop114407458.taobao.com
Aliexpress: https://minibalance.aliexpress.com/store/4455017
Version: V1.0
Update：2022-09-01

All rights reserved
***********************************************/
#ifndef __USART_H
#define __USART_H
#include "stdio.h"
#include "sys.h"
#define RECEIVE_DATA_SIZE 11             //接收数据组大小
#define FRAME_HEADER      0X7B          //帧头
#define FRAME_tail        0X7D          //帧尾
typedef struct _RECEIVE_DARA_
{
	u8 buffer[RECEIVE_DATA_SIZE];
	unsigned char PC_buffer[12];
}RECEIVE_DATA;
extern u8 Send_Data[12];

/* ---- 摄像头数据 ---- */
extern volatile int  camera_error_x;     // X轴像素误差
extern volatile int  camera_error_y;     // Y轴像素误差
extern volatile int  camera_w;           // 边界框宽度
extern volatile int  camera_h;           // 边界框高度
extern volatile u8   camera_ball_flag;   // 0=无球, 1=有球
extern volatile u8   camera_data_ready;  // 1=有新数据待处理
extern volatile int  camera_vx;          // 水平速度 (0.01cm/s)
extern volatile int  camera_vy;          // 垂直速度 (0.01cm/s)

/* ---- VOFA+ 命令接收 (USART3 RX) ---- */
#define VOFA_BUF_SIZE   20
extern volatile u8   vofa_cmd_ready;
extern volatile u8   vofa_param_id;
extern volatile float vofa_param_value;

void uart_init(u32 bound);
void usart1_send(u8 data);
u8 CRC_Sum(unsigned char Count_Number);
float Speed_transition(u8 High,u8 Low);
u32 Position_transition(u8 High,u8 Low);
float SPeed_transition(u8 High,u8 Low);
float Angle_transition(u8 High,u8 Low);
float Baud_transition(u8 High,u8 middle,u8 Low);
void uart3_init(u32 bound);
void data_transition(void);
void USART1_SEND(u8* data,u8 len);
u8 CRC_Sum1(unsigned char Count_Number);
void USART2_SEND(u8* data,u8 len);
u8 BCC_Sum1(u8* usart_data,unsigned char Count_Number);
void uart2_init(u32 bound);
void usart2_send(u8 data);
void VOFA_SendFireWater(float *data, u8 count);
#endif
