/***********************************************
 * 管球平衡 — USART 模块 (STM32F103C8T6 标准外设库)
 *
 * USART1 (PA9/PA10): 摄像头 (已占用)
 * USART2 (PA2/PA3):  电机通信
 * USART3 (PB10/PB11): VOFA+ 双向
 ***********************************************/
#include "sys.h"
#include "usart.h"

u8 Send_Data[12];
extern int Time_count;
RECEIVE_DATA Receive_Data;
#define CONTROL_DELAY		1000

/* ---- VOFA+ 全局变量 (USART3 ISR 写入, main 读取) ---- */
volatile u8   vofa_cmd_ready    = 0;
volatile u8   vofa_param_id     = 0;
volatile float vofa_param_value = 0.0f;

/* ---- 摄像头速度 (USART1 ISR 写入) ---- */
volatile int camera_vx = 0;
volatile int camera_vy = 0;

/* ---- VOFA 解析器静态变量 (USART3 ISR内使用) ---- */
static u8 vofa_state = 0;
static u8 vofa_idx   = 0;
static u8 vofa_buf[VOFA_BUF_SIZE];

/* ---- 简易 atof (ISR 中解析浮点字符串) ---- */
static float vofa_atof(const u8 *s, u8 len)
{
	float val = 0.0f, frac = 0.0f, sign = 1.0f;
	u8 i = 0, dot = 0;
	float div = 10.0f;

	if(len == 0) return 0.0f;
	if(s[0] == '-') { sign = -1.0f; i = 1; }

	for(; i < len; i++)
	{
		if(s[i] == '.') { dot = 1; continue; }
		if(s[i] < '0' || s[i] > '9') break;
		if(dot)
		{
			frac += (float)(s[i] - '0') / div;
			div *= 10.0f;
		}
		else
		{
			val = val * 10.0f + (float)(s[i] - '0');
		}
	}
	return sign * (val + frac);
}

#if SYSTEM_SUPPORT_OS
#include "includes.h"					//ucos 使用
#endif

//////////////////////////////////////////////////////////////////
//加入以下代码,支持printf函数,而不需要选择use MicroLIB
#if 1
#pragma import(__use_no_semihosting)
//标准库需要的支持函数
struct __FILE
{
	int handle;
};

FILE __stdout;
//定义_sys_exit()以避免使用半主机模式
_sys_exit(int x)
{
	x = x;
}
//重定义fputc函数
int fputc(int ch, FILE *f)
{
	while((USART1->SR&0X40)==0);
	USART1->DR = (u8) ch;
	return ch;
}
#endif

/**************************************************************************
Function: Serial port 1 initialization
Input   : bound：Baud rate
Output  : none
**************************************************************************/
void uart_init(u32 bound)
{
  //GPIO端口设置
  GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1|RCC_APB2Periph_GPIOA, ENABLE);	//使能USART1，GPIOA时钟

	//USART1_TX   GPIOA.9
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; //PA.9
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//复用推挽输出
  GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA.9

  //USART1_RX	  GPIOA.10初始化
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;//PA10
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//浮空输入
  GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA.10

	//Usart1 NVIC 配置
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1 ;//抢占优先级1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		//子优先级1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);	//根据指定的参数初始化VIC寄存器


	USART_InitStructure.USART_BaudRate = bound;//串口波特率
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//收发模式

    USART_Init(USART1, &USART_InitStructure); //初始化串口1
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//开启串口接受中断
    USART_Cmd(USART1, ENABLE);                    //使能串口1
}

u8 usart2_receive_data[10];

/**************************************************************************
Function: Serial port 2 initialization
Input   : bound：Baud rate
Output  : none
**************************************************************************/
void uart2_init(u32 bound)
{
    //GPIO端口设置
    GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	DMA_InitTypeDef DMA_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	//使能GPIOA时钟
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);	//使能USART2
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);

	//USART2_TX   GPIOA.2
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; //PA.2
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//复用推挽输出
    GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA.2

    //USART2_RX	  GPIOA.3初始化
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;//PA3
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//浮空输入
    GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA.3

	USART_InitStructure.USART_BaudRate = bound;//串口波特率
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//收发模式
	USART_Init(USART2, &USART_InitStructure);

    DMA_DeInit(DMA1_Channel6);
	DMA_InitStructure.DMA_BufferSize = 10;//缓冲区最大长度是47个字节
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;//串口接收，外设到内存
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)usart2_receive_data;
	DMA_InitStructure.DMA_MemoryDataSize = 	DMA_MemoryDataSize_Byte;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)(&USART2->DR);
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_Init(DMA1_Channel6,&DMA_InitStructure);
	DMA_ClearFlag(DMA1_FLAG_TC6);
	DMA_Cmd(DMA1_Channel6,ENABLE);

	//Usart2 NVIC 配置
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1 ;//抢占优先级1
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		//子优先级1
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);	//根据指定的参数初始化VIC寄存器


    USART_ITConfig(USART2, USART_IT_IDLE, ENABLE);//开启串口接受中断
	USART_DMACmd(USART2,USART_DMAReq_Rx,ENABLE);
    USART_Cmd(USART2, ENABLE);                    //使能串口2
}



/**************************************************************************
Function: Serial port 1 sends data
Input   : The data to send
Output  : none
**************************************************************************/
void usart1_send(u8 data)
{
	USART1->DR = data;
	while((USART1->SR&0x40)==0);
}

/**************************************************************************
Function: Serial port 1 sends data
Input   : none
Output  : none
**************************************************************************/
void USART1_SEND(u8* data,u8 len)
{
     u8 i = 0;
	for(i=0; i<len; i++)
	{
		usart1_send(data[i]);
	}
}

/**************************************************************************
Function: Serial port 2 sends data
Input   : The data to send
Output  : none
**************************************************************************/
void usart2_send(u8 data)
{
	USART2->DR = data;
	while((USART2->SR&0x40)==0);
}

/**************************************************************************
Function: Serial port 2 sends data
Input   : none
Output  : none
**************************************************************************/
void USART2_SEND(u8* data,u8 len)
{
     u8 i = 0;
	for(i=0; i<len; i++)
	{
		usart2_send(data[i]);
	}
}

/**************************************************************************
Function: Serial port 3 sends a byte
**************************************************************************/
static void usart3_send(u8 data)
{
	USART3->DR = data;
	while((USART3->SR&0x40)==0);
}



/***********************************************************
Function: Calculates the check bits of data to be received
Inpuut  : Count_Number:the first few digits of a check;
Output  : Check result
*************************************************************/
u8 BCC_Sum1(u8* usart_data,unsigned char Count_Number)
{
    unsigned char crc_sum = 0,k;
	for(k=0;k<Count_Number;k++)
	{
		crc_sum=crc_sum^usart_data[k];
	}
	return crc_sum;
}


/***************************************************************************
Function:Serial port 1 receive interrupt — camera binary frame parser
Format : $ [X_2B] [Y_2B] [W_2B] [H_2B] [ball_1B] #
          $=0x24  #=0x23  ball: 0x00=无球 0x01=有球
          X/Y = int16 LE,  W/H = uint16 LE
Length : 11 bytes total (1 header + 9 data + 1 trailer)
***************************************************************************/
#define CAM_DATA_LEN 9   // X(2) + Y(2) + W(2) + H(2) + ball(1)
void USART1_IRQHandler(void)
{
    u8 ch;
    static u8 cam_buf[CAM_DATA_LEN];
    static u8 cam_idx  = 0;
    static u8 cam_sync = 0;   // 0=waiting for '$', 1=receiving

    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        ch = USART_ReceiveData(USART1);
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);

        if(cam_sync == 0)
        {
            if(ch == 0x24)      // '$'
            {
                cam_sync = 1;
                cam_idx  = 0;
            }
        }
        else
        {
            if(ch == 0x23 && cam_idx == CAM_DATA_LEN)  // '#' after all data
            {
                /* ---- parse X(2) Y(2) W(2) H(2) ball(1) ---- */
                camera_error_x = (int16_t)( cam_buf[0]
                              | ((int)cam_buf[1] << 8));
                camera_error_y = (int16_t)( cam_buf[2]
                              | ((int)cam_buf[3] << 8));
                camera_w       = (int)( cam_buf[4]
                              | ((int)cam_buf[5] << 8));
                camera_h       = (int)( cam_buf[6]
                              | ((int)cam_buf[7] << 8));
                camera_ball_flag   = cam_buf[8];
                camera_data_ready  = 1;
                cam_sync = 0;
            }
            else if(cam_idx < CAM_DATA_LEN)
            {
                cam_buf[cam_idx++] = ch;
            }
            else
            {
                cam_sync = 0;   // 帧异常，重置
            }
        }
    }
}

/***************************************************************************
Function:Serial port 2 receive interrupt
Input   :none
Output  :none
***************************************************************************/
void USART2_IRQHandler(void)
{
	u8 Usart2_Receive;
	if(USART_GetITStatus(USART2,USART_IT_IDLE)!=RESET)
	{
		Usart2_Receive=USART_ReceiveData(USART2);//读取数据
		DMA_Cmd(DMA1_Channel6,DISABLE);
		if(usart2_receive_data[7]==BCC_Sum1(usart2_receive_data,7))
		{
			if(usart2_receive_data[1]==0x02)
			{
				if(usart2_receive_data[2] == 0x01)
			       Motor2_Current_Position = (usart2_receive_data[3]<<24)+(usart2_receive_data[4]<<16)+(usart2_receive_data[5]<<8)+usart2_receive_data[6];
			}
		}
		DMA_SetCurrDataCounter(DMA1_Channel6,10);
	    DMA_Cmd(DMA1_Channel6,ENABLE);
	}
}

/* ================================================================
 * USART3 初始化 (PB10=TX, PB11=RX) — VOFA+ 专用
 *   波特率 115200, 8N1
 * ================================================================ */
void uart3_init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

	// PB10: USART3_TX
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// PB11: USART3_RX
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	USART_InitStructure.USART_BaudRate = bound;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	USART_Init(USART3, &USART_InitStructure);
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
	USART_Cmd(USART3, ENABLE);
}

/* ================================================================
 * VOFA+ FireWater 发送 (USART3 TX, PB10)
 *
 * 文本CSV格式: "val0,val1,val2,val3,val4\r\n"
 * VOFA+ 选择 "FireWater" 协议即可
 * ================================================================ */
void VOFA_SendFireWater(float *data, u8 count)
{
	char buf[80];
	u8 i, pos = 0;
	for(i = 0; i < count; i++)
	{
		/* 格式化每个浮点数, 保留2位小数 */
		if(i < count - 1)
			pos += sprintf(buf + pos, "%.2f,", data[i]);
		else
			pos += sprintf(buf + pos, "%.2f\r\n", data[i]);
	}
	/* 发送整行 */
	for(i = 0; i < pos; i++)
		usart3_send((u8)buf[i]);
}


/* ================================================================
 * USART3 中断 — VOFA+ 命令解析
 *
 * 帧格式: #P{id}={value}!
 *         #=0x23  P=0x50  !=0x21
 *         id: 1=Kp  2=Ki  3=Kd
 *         value: 浮点数字符串 (如 "0.185", "-0.5")
 * ================================================================ */
void USART3_IRQHandler(void)
{
	u8 ch;

	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
	{
		ch = USART_ReceiveData(USART3);
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);

		switch(vofa_state)
		{
		case 0:  // 空闲, 等待 '#'
			if(ch == 0x23) vofa_state = 1;
			break;

		case 1:  // 等待 'P'
			if(ch == 0x50) vofa_state = 2;
			else           vofa_state = 0;
			break;

		case 2:  // 等待参数ID ('1'~'9')
			if(ch >= 0x31 && ch <= 0x39)
			{
				vofa_param_id = ch - 0x30;
				vofa_state = 3;
			}
			else vofa_state = 0;
			break;

		case 3:  // 等待 '='
			if(ch == 0x3D)
			{
				vofa_state = 4;
				vofa_idx   = 0;
			}
			else vofa_state = 0;
			break;

		case 4:  // 读取 value, 直到 '!'
			if(ch == 0x21)
			{
				vofa_param_value = vofa_atof(vofa_buf, vofa_idx);
				vofa_cmd_ready   = 1;
				vofa_state = 0;
			}
			else if(vofa_idx < VOFA_BUF_SIZE - 1)
			{
				vofa_buf[vofa_idx++] = ch;
			}
			else
			{
				vofa_state = 0;  // 溢出复位
			}
			break;

		default:
			vofa_state = 0;
			break;
		}
	}
}
